import React from 'react';
import './App.css';
import MainCard from "./components/card";
import Header from "./components/header";
import Footer from "./components/footer";

function App() {
  return (
    <div className="App">
        <Header/>
        <MainCard/>
        <Footer/>
    </div>
  );
}

export default App;
