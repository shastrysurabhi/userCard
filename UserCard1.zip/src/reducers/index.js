const initialState = [{
  '1': {
      name: 'AAA',
      subCard: {
          id: {
              name: 'subAAA',
              description: 'description',
              list: ['task1', 'task2', 'task3'],
              subCard: {}
          }
      }
  }
}];

const tasks = (state = initialState, action) => {
    switch (action.type) {
        case 'ADD_TASK':
            return [
                ...state,
                {
                    id: action.id,
                    task: action.task
                }
            ];
       /* case 'DELETE_TASK':
            return
        case 'EDIT_TASK':
            return
        case 'CHECK_TASK':
            return
        case 'UNCHECK_TASK':
            return*/
    }
};

export default tasks;