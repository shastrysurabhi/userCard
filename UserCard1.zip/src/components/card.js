import React from 'react';
import CheckListSubCard from "./checkListSubCard";
import Constants from '../AppConstants';

var data = Object.keys(Constants.cardData);

const MainCard = () => (
  <div className="card" style={{width:'50%', margin: '10px'}}>
      <div className="card-body">
              <h5 className="card-title"> {Constants.cardData[data].name}
          </h5>
          <CheckListSubCard/>
      </div>
  </div>
);

export default MainCard;