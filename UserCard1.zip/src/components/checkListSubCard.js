import React from 'react';
import Constants from '../AppConstants';
import Checkbox from "./checkbox";

let list = Constants.cardData['1'].subCard[0]['1'];

let checklistItems = list.listItems.map((eachObject) => {
    return <li className="list-group-item" key={eachObject}><Checkbox/> {eachObject} </li>
});

const CheckListSubCard = () => (
    <div className="card" style={{width:'75%'}}>
        <div className="card-body">
            <h5 className="card-title">
               {list.description}
            </h5>
            {/*CheckList*/}
            <ul className="list-group list-group-flush">
            {checklistItems}
            </ul>
        </div>
    </div>
);

export default CheckListSubCard;