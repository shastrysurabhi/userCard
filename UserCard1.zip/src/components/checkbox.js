import React from 'react';

const Checkbox = () => (
    <span><input type="checkbox"/></span>
);

export default Checkbox;