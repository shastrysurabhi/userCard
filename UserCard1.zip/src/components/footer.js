import React from 'react';
import './../App.css';

class Footer extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <footer className="App-footer"></footer>
        );
    }

}

export default Footer;