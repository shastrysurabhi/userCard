const CONSTANTS = {
    cardData: {
        '1': {
            name: 'AAA',
            subCard: [{
                '1': {
                    name: 'subAAA',
                    description: 'description',
                    listItems: ['task1', 'task2', 'task3'],
                    subCard: {}
                }
            }]
        }
    }
};

export default CONSTANTS;