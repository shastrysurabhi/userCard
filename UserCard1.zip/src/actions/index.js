export const addTask = task => ({
    type: 'ADD_TASK',
    id: nextTask++,
    taskDetails
});

export const deleteTask = task => ({
    type: 'DELETE_TASK',
    id
});

export const  editTask = task => ({
   type: 'EDIT_TASK',
   id
});

export const check = task => ({
   type: 'CHECK_TASK',
   id
});

export const uncheck = task => ({
   type: 'UNCHECK_TASK',
   id
});